document.addEventListener('DOMContentLoaded', function () {
    //Weather
    const city = 'Sydney';
    const apiKey = '4399e61ff976dbdc7c1fa31f78f9739a'; 
    const weatherUrl = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`;

    fetch(weatherUrl)
        .then(response => response.json())
        .then(data => {
            const temperature = data.main.temp;
            const weatherDescription = data.weather[0].description;
            const humidity = data.main.humidity;

            document.getElementById('weather').innerHTML = `
                <h3>Current Weather in ${city}:</h3>
                <p>Temperature: ${temperature}°C</p>
                <p>Condition: ${weatherDescription}</p> 
                <p>Humidity: ${humidity}%</p>
            `;
        })
        .catch(error => {
            console.error('Error fetching weather data:', error);
            document.getElementById('weather').innerHTML = '<p>Failed to load weather data.</p>';
        });
    });

    //map
    document.addEventListener('DOMContentLoaded', function () {
        const lat = -33.8688;
        const lng = 151.2093;
        const username = 'miabusuttil14'; 
    
        const geonamesUrl = `http://api.geonames.org/findNearbyWikipediaJSON?lat=${lat}&lng=${lng}&username=${username}&maxRows=500`;
        
        
        const map = L.map('map').setView([lat, lng], 13);
    
        
        L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
            maxZoom: 19,
            attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
        }).addTo(map);
    
        //markers
        fetch(geonamesUrl)
            .then(response => response.json())
            .then(data => {
                console.log('GeoNames data:', data);  
    
                if (data.geonames && data.geonames.length > 0) {
                    
                    data.geonames.forEach(location => {
                        console.log(location);  
    
                        
                        if (location.lat && location.lng && location.title && location.summary && location.wikipediaUrl) {
                            const marker = L.marker([location.lat, location.lng]).addTo(map);
                            marker.bindPopup(`
                                <strong>${location.title}</strong><br>
                                ${location.summary}<br>
                                <a href="https://${location.wikipediaUrl}" target="_blank">Learn more</a>
                            `);
                        } else {
                            console.warn('Missing data for marker:', location);
                        }
                    });
                } else {
                    console.error('No hotspots found in the response data.');
                }
            })
            .catch(error => {
                console.error('Error fetching GeoNames data:', error);
            });
    });
    
    
    
    