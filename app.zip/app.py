from flask import Flask, render_template
import json
from datetime import datetime

app = Flask(__name__)

REVIEWS_FILE ='reviews.json'

@app.route('/')
def website():
    return render_template('website.html')

@app.route('/userreview')
def userreview():
    return render_template('userreview.html')
    
@app.route('/reviews', methods=['GET'])
def list_reviews():
	with open(REVIEWS_FILE, 'r') as file:
		reviews=json.load(file)
	return jsonify(reviews)
    
@app.route('/photo')
def photo():
    return render_template('photo.html')
    
@app.route('/history')
def history():
    return render_template('history.html')
    
if __name__ == '__main__':
    app.run(debug=True)

